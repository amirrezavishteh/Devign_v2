"""Single-function vulnerability inference.

Loads a trained Devign model + the saved featurizer, builds the composite graph for one C
function, and returns P(vulnerable). Usable as a library (predict_function) or CLI.

Usage:
    python -m inference.predict --file path/to/func.c
    python -m inference.predict --code "int f(){...}"
    echo "int f(){...}" | python -m inference.predict
"""
from __future__ import annotations

import argparse
import os
import sys

import torch

from data.dataset import GraphSample, make_collate_fn
from data.graph_builder import EDGE_TYPES, build_graph
from data.word2vec_embed import NodeFeaturizer
from models.devign import build_model
from training.utils import load_config, resolve_device


class DevignPredictor:
    def __init__(self, config_path="config.yaml", model_name="devign", device=None):
        self.cfg = load_config(config_path)
        self.device = device or resolve_device(self.cfg["project"]["device"])
        proc = self.cfg["data"]["processed_dir"]
        self.featurizer = NodeFeaturizer.load(os.path.join(proc, "featurizer"))
        self.edge_types = EDGE_TYPES
        self.collate = make_collate_fn(self.edge_types)
        self.model = build_model(
            model_name, self.cfg, code_dim=self.cfg["embedding"]["word2vec_dim"],
            type_vocab_size=len(self.featurizer.type_vocab), num_edge_types=len(self.edge_types))
        model_path = os.path.join(self.cfg["project"]["artifacts_dir"], model_name, "model.pt")
        self.model.load_state_dict(torch.load(model_path, map_location=self.device,
                                              weights_only=True))
        self.model.to(self.device).eval()

    @torch.no_grad()
    def predict(self, source: str, threshold: float = 0.5) -> dict:
        graph = build_graph(source, max_nodes=self.cfg["data"]["max_nodes"])
        if graph is None or graph.num_nodes == 0:
            return {"error": "could not parse function or it exceeds max_nodes",
                    "vulnerable": None, "probability": None}
        code_feat, type_ids = self.featurizer.featurize_graph(graph)
        edges = {}
        import numpy as np
        for et in self.edge_types:
            elist = graph.edges.get(et, [])
            edges[et] = (np.array(elist, dtype=np.int64).T if elist
                         else np.zeros((2, 0), dtype=np.int64))
        sample = GraphSample(code_feat=code_feat, type_ids=type_ids, edges=edges,
                             num_nodes=graph.num_nodes, label=0, project="inference")
        batch = self.collate([sample]).to(self.device)
        prob = torch.sigmoid(self.model(batch)).item()
        return {
            "vulnerable": bool(prob >= threshold),
            "probability": prob,
            "num_nodes": graph.num_nodes,
            "edge_counts": {et: len(graph.edges.get(et, [])) for et in self.edge_types},
        }


def predict_function(source: str, config_path="config.yaml", model_name="devign") -> dict:
    return DevignPredictor(config_path, model_name).predict(source)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--model", default="devign")
    ap.add_argument("--file", default=None)
    ap.add_argument("--code", default=None)
    ap.add_argument("--threshold", type=float, default=0.5)
    args = ap.parse_args()

    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            source = f.read()
    elif args.code:
        source = args.code
    else:
        source = sys.stdin.read()

    if not source.strip():
        print("No source provided.")
        sys.exit(1)

    predictor = DevignPredictor(args.config, args.model)
    result = predictor.predict(source, threshold=args.threshold)
    if result.get("error"):
        print(f"Error: {result['error']}")
        sys.exit(2)
    verdict = "VULNERABLE" if result["vulnerable"] else "NON-VULNERABLE"
    print(f"Prediction : {verdict}")
    print(f"P(vuln)    : {result['probability']:.4f}")
    print(f"Nodes      : {result['num_nodes']}")
    print(f"Edges      : {result['edge_counts']}")


if __name__ == "__main__":
    main()
