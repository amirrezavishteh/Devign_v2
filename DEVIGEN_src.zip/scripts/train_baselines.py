"""CLI: train the Table-2 baselines and report per-project metrics.

Usage:
    python -m scripts.train_baselines --config config.yaml
"""
from __future__ import annotations

import argparse
import json
import os

from evaluation.report import per_project_eval
from training.train_baselines import (train_bilstm, train_cnn,
                                      train_metrics_xgboost)
from training.trainer import evaluate
from training.utils import ensure_dir, load_config, resolve_device, set_seed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--epochs", type=int, default=None)
    args = ap.parse_args()
    cfg = load_config(args.config)
    if args.epochs:
        cfg["training"]["epochs"] = args.epochs
    set_seed(cfg["project"]["seed"])
    device = resolve_device(cfg["project"]["device"])
    out_dir = ensure_dir(os.path.join(cfg["project"]["artifacts_dir"], "baselines"))

    results = {}

    print("[baselines] 3-layer BiLSTM")
    model, best = train_bilstm(cfg, device, attention=False)
    _, probs, labels, projects = evaluate(model, _val_seq_loader(cfg), device)
    results["3-layer BiLSTM"] = per_project_eval(probs, labels, projects)

    print("[baselines] 3-layer BiLSTM + Att")
    model, best = train_bilstm(cfg, device, attention=True)
    _, probs, labels, projects = evaluate(model, _val_seq_loader(cfg), device)
    results["3-layer BiLSTM + Att"] = per_project_eval(probs, labels, projects)

    print("[baselines] CNN")
    model, best = train_cnn(cfg, device)
    _, probs, labels, projects = evaluate(model, _val_seq_loader(cfg), device)
    results["CNN"] = per_project_eval(probs, labels, projects)

    print("[baselines] Metrics + XGBoost")
    _, _, (Xva, yva, proj_va, preds) = train_metrics_xgboost(cfg)
    results["Metrics + Xgboost"] = per_project_eval(preds, yva, proj_va)

    # Serialize (metrics only).
    serializable = {k: {p: m for p, m in v.items()} for k, v in results.items()}
    with open(os.path.join(out_dir, "baseline_metrics.json"), "w") as f:
        json.dump(serializable, f, indent=2)
    print(f"[baselines] saved metrics to {out_dir}")


def _val_seq_loader(cfg):
    import pickle
    from torch.utils.data import DataLoader
    from models.baselines import SequenceDataset, make_seq_collate
    proc = cfg["data"]["processed_dir"]
    with open(os.path.join(proc, "sequences.pkl"), "rb") as f:
        seq = pickle.load(f)
    return DataLoader(SequenceDataset(seq["val"], seq["max_len"]),
                      batch_size=cfg["training"]["batch_size"], shuffle=False,
                      collate_fn=make_seq_collate(seq["max_len"]))


if __name__ == "__main__":
    main()
